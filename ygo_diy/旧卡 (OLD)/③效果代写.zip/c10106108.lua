function c10106108.initial_effect(c)
	--xyz summon
	aux.AddXyzProcedure(c,aux.FilterBoolFunction(Card.IsSetCard,0xba5),4,3)
	c:EnableReviveLimit()
	--remove
	local e1=Effect.CreateEffect(c)
	e1:SetDescription(aux.Stringid(10106108,1))
	e1:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_F)
	e1:SetCode(EVENT_SPSUMMON_SUCCESS)
	e1:SetCountLimit(1,10106108)
	e1:SetCondition(c10106108.rmcon)
	e1:SetTarget(c10106108.rmtg)
	e1:SetOperation(c10106108.rmop)
	c:RegisterEffect(e1)
		--attribute
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetRange(LOCATION_MZONE)
	e2:SetTargetRange(LOCATION_MZONE,0)
	e2:SetCode(EFFECT_CHANGE_ATTRIBUTE)
	e2:SetTarget(aux.TargetBoolFunction(Card.IsFaceup))
	e2:SetValue(ATTRIBUTE_DARK)
	c:RegisterEffect(e2)
	 --spsummon
	local e3=Effect.CreateEffect(c)
	e3:SetDescription(aux.Stringid(10106108,2))
	e3:SetCategory(CATEGORY_SPECIAL_SUMMON)
	e3:SetType(EFFECT_TYPE_IGNITION)
	e3:SetRange(LOCATION_MZONE)
	e3:SetCountLimit(1,10106109)
	e3:SetTarget(c10106108.sptg)
	e3:SetOperation(c10106108.spop)
	c:RegisterEffect(e3)
end
function c10106108.sptg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return Duel.GetLocationCount(tp,LOCATION_MZONE)>0
		and e:GetHandler():GetOverlayCount()>0
	end
end
function c10106108.spop(e,tp,eg,ep,ev,re,r,rp)
	if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 or not e:GetHandler():CheckRemoveOverlayCard(tp,1,REASON_EFFECT) then return end
	repeat
		e:GetHandler():RemoveOverlayCard(tp,1,1,REASON_EFFECT)
		ct=Duel.GetOperatedGroup():GetFirst()
		if not ct:IsType(TYPE_MONSTER) then
			Duel.Overlay(e:GetHandler(),ct)
		else
			break
		end
	until(ct:IsType(TYPE_MONSTER))
	Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
	if ct:IsType(TYPE_MONSTER) then
		Duel.SpecialSummon(ct,0,tp,tp,false,false,POS_FACEUP)
	else 
		Duel.Overlay(e:GetHandler(),ct) 
		return false 
	end 
end


function c10106108.rmcon(e,tp,eg,ep,ev,re,r,rp)
	return e:GetHandler():IsSummonType(SUMMON_TYPE_XYZ)
end
function c10106108.filter2(c)
	return c:IsCanOverlay()
end
function c10106108.rmtg(e,tp,eg,ep,ev,re,r,rp,chk)
	if chk==0 then return true end
	local g=Duel.GetMatchingGroup(c10106108.filter2,tp,LOCATION_FZONE,LOCATION_MZONE,nil)
	Duel.SetOperationInfo(0,CATEGORY_REMOVE,g,g:GetCount(),0,0)
end
function c10106108.rmop(e,tp,eg,ep,ev,re,r,rp)
	local c=e:GetHandler()
	local g=Duel.GetMatchingGroup(c10106108.filter2,tp,LOCATION_FZONE,LOCATION_MZONE,nil)
	if g:GetCount()>0 then
		Duel.Overlay(c,g)
	end
end